﻿using System;
using System.Linq.Expressions;

namespace ClassLibrary
{
    public class Cykel
    {
        #region Instance Field
        private int _id;
        private string _color;
        private int _price;
        private int _gear;
        private bool check1;
        private bool check2;
        private bool check3;
        private bool check4;
        #endregion
        #region Constructor
        public Cykel(int id, string color, int price, int gear)
        {
            ColorCheck(color);
            PriceCheck(price);
            Gearcheck(gear);
            IDcheck(id);
           if ((check1== true)&&(check2 == true)&&(check3 ==true)&&(check4 == true))
            {
                _id = id;
                _color = color;
                _price = price;
                _gear = gear;
            }
            else
            {
                if(check1 == false)
                {
                    throw new ArgumentException("Color must be at least 1 character");
                }
                else if (check2 == false)
                {
                    throw new ArgumentException("Price Cannot be 0 or below");
                }
                else if (check3 == false)
                {
                    throw new ArgumentException("Gear must be between or exactly 3 and 32");
                }
                else
                {
                    throw new ArgumentException("ID must at least one non-negative number");
                }
            }
        }
        #endregion
        #region Properties
        public int ID
        {
            get { return _id; }
            set { _id = value; }
          
        }

        
        public string Color 
        {
            get { return _color; }
            set { _color = value; }
          
        }
        public int Price
        {
            get { return _price; }
            set { _price = value; }

        }
        public int Gear
        {
            get { return _gear; }
            set { _gear = value; }

        }

        #endregion
        #region Methods
        public void ColorCheck(string color)
        {
            if(color.Length >= 1)
            {
                check1 = true;
            }
        }
        public void PriceCheck(int price)
        {

            if (price > 0)
            {
                check2 = true;
            }
        }
        public void Gearcheck(int gear)
        {
            if ((3 <= gear) && (gear <= 32))
            {
                check3 = true;
            }
        }
        public void IDcheck(int id)
        {
            if (id >= 1)
            {
                check4 = true;
            }
        }


        #endregion
    }
}
