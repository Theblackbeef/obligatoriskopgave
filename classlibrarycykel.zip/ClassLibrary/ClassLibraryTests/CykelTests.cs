﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ClassLibrary;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq.Expressions;
using System.Security.Cryptography.X509Certificates;
using System.Drawing;

namespace ClassLibrary.Tests
{
    [TestClass()]
    public class CykelTests
    {

        [TestMethod()]
        public void CykelTest3()
        {
            //Test to see if i can create an object
            Cykel cykel1 = new Cykel(1, "blue", 1, 3);

            Assert.AreEqual("blue", cykel1.Color);
        }

        [TestMethod()]
        public void Cykeltest4()
        {

            //Color check
            var ex = Assert.ThrowsException<ArgumentException>(() => new Cykel(1, "", 1, 3));
            Assert.AreEqual("Color must be at least 1 character", ex.Message);



        }

        [TestMethod()]
        public void CykelTest5()
        {
            // if it works with the one above it works with every one of the checks
        }


    }
}